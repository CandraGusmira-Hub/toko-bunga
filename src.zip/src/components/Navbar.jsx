import { useState } from 'react'
import { BRAND } from '../config'

const LINKS = [
  { href: '#katalog', label: 'Katalog' },
  { href: '#custombunga', label: 'Custom' },
  { href: '#keunggulan', label: 'Keunggulan' },
  { href: '#kontak', label: 'Kontak' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-20 backdrop-blur bg-[#fff7f8]/85 border-b border-rose-100">
      <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between gap-3">
        <a href="#" className="font-display text-lg sm:text-2xl font-bold text-rose-600 truncate">
          {BRAND}
        </a>

        <nav className="hidden md:flex gap-6 lg:gap-8 text-sm font-medium">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} className="hover:text-rose-600 transition">
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <a
            href="#katalog"
            className="text-xs sm:text-sm font-semibold bg-rose-500 text-white rounded-full px-4 sm:px-5 py-2 hover:bg-rose-600 transition whitespace-nowrap"
          >
            Belanja
          </a>
          <button
            type="button"
            aria-label="Buka menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="md:hidden h-10 w-10 -mr-2 flex items-center justify-center text-2xl leading-none"
          >
            {open ? '✕' : '☰'}
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden border-t border-rose-100 px-5 py-2 flex flex-col text-sm font-medium">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="py-3 hover:text-rose-600">
              {l.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  )
}
